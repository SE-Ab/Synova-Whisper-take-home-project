# Audit Pack Verification

This audit pack contains components to verify inference requests.

## Contents
- `MANIFEST.json`: List of files and their SHA256 hashes.
- `MANIFEST.json.sig`: Ed25519 signature of the manifest.
- `audit/`: Contains the signed JSONL audit logs.
- `repro/`: Contains the `inference_replay.py` script.